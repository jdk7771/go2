#!/usr/bin/env python3
"""Uniform-initialization, matched-cloud 3/4/6 DOF ablation.

The optimizer accepts no Scene, obstacle parameters, seed hints, or truth cloud.
Every optimization finishes before the held-out surfaces are scored. Geometry
may be loaded from URDF/config or explicitly replayed from recorded metadata.
"""

from __future__ import annotations

import os

# Set before NumPy/SciPy imports, including in spawned workers. Prevent nested
# BLAS parallelism from obscuring process CPU time and oversubscribing the host.
for _thread_var in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_thread_var] = "1"

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from datetime import datetime
from multiprocessing import get_context
from pathlib import Path
from zoneinfo import ZoneInfo

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
from scipy.optimize import minimize

import m20_core as core
import run_3d_suite as suite


MODES = ("translation", "translation_yaw", "full")
LABELS = {"translation": "XYZ", "translation_yaw": "XYZ + yaw", "full": "Full 6D"}
COLORS = dict(zip(MODES, ("tab:blue", "tab:orange", "tab:green")))
KEY_SCENES = (
    "beam_h430_yaw00_tilt+0",
    "tilted_corridor_30deg",
    "asymmetric_overhang_slalom",
)
HERE = Path(__file__).resolve().parent


def write_json(path: Path, value: dict | list) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def array_digest(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def projected_gradient(x: np.ndarray, gradient: np.ndarray, bounds: np.ndarray) -> np.ndarray:
    """Unit-step gradient mapping x - projection_[lower,upper](x - grad)."""
    return x - np.clip(x - gradient, bounds[:, 0], bounds[:, 1])


def load_robot(urdf: Path | None, config: Path | None, reference: Path) -> tuple[np.ndarray, float, dict]:
    if (urdf is None) != (config is None):
        raise ValueError("Supply both --urdf and --m20-config, or neither for metadata replay")
    if urdf is not None:
        center, half, mass = core.derive_m20_body_obb(urdf)
        if np.linalg.norm(center) > 1.0e-8:
            raise ValueError("The current collision kernel requires a centered body OBB")
        height = core.read_nominal_height(config)
        provenance = {"kind": "urdf_and_config", "urdf": str(urdf), "config": str(config)}
    else:
        recorded = json.loads(reference.read_text(encoding="utf-8"))["metadata"]
        half = np.asarray(recorded["m20_body_obb_size_m"], dtype=float) / 2.0
        height = float(recorded["nominal_height_m"])
        mass = float(recorded["m20_base_mass_kg"])
        provenance = {
            "kind": "recorded_robot_geometry_replay",
            "reference": str(reference),
            "reference_sha256": hashlib.sha256(reference.read_bytes()).hexdigest(),
            "original_urdf": recorded["urdf"],
            "original_config": recorded["config"],
            "note": "Robot constants only; source URDF/config are not present or independently revalidated.",
        }
    provenance.update(body_size_m=(2 * half).tolist(), nominal_height_m=height, base_mass_kg=mass)
    return half, height, provenance


def optimize_from_cloud(
    cloud: np.ndarray,
    initial: np.ndarray,
    half: np.ndarray,
    nominal_height: float,
    mode: str,
    maxiter: int,
    pose_history: list[np.ndarray] | None = None,
) -> tuple[np.ndarray, dict, list[dict], np.ndarray]:
    """Planning boundary: no access to scene metadata or validation surfaces."""
    problem = core.TrajectoryProblem(
        cloud, np.full(len(cloud), suite.POINT_VOXEL**2), initial, half,
        nominal_height, suite.PLANNING_CLEARANCE, mode, suite.planner_weights(),
    )
    bounds = np.asarray(problem.bounds())
    x0 = problem.pack(initial)
    history: list[dict] = []
    cached_x = None
    cached_value = None

    def evaluate(x):
        nonlocal cached_x, cached_value
        if cached_x is None or not np.array_equal(x, cached_x):
            cached_x = x.copy()
            cached_value = problem.cost_grad(x)
        return cached_value

    def record(x):
        cost, grad = evaluate(x)
        poses = problem.unpack(x)
        if pose_history is not None:
            pose_history.append(poses.copy())
        history.append({
            "iteration": len(history),
            "cost": float(cost),
            "gradient_inf_norm": float(np.linalg.norm(grad, ord=np.inf)),
            "projected_gradient_inf_norm": float(np.linalg.norm(projected_gradient(x, grad, bounds), ord=np.inf)),
            "minimum_base_z_m": float(poses[:, 2].min()),
            "max_abs_roll_deg": float(np.abs(np.degrees(poses[:, 3])).max()),
            "max_abs_pitch_deg": float(np.abs(np.degrees(poses[:, 4])).max()),
            "max_abs_yaw_deg": float(np.abs(np.degrees(poses[:, 5])).max()),
        })

    initial_wrenches = []
    for pose in initial:
        _, force, torque, _, _ = core.collision_energy_wrench(
            cloud, problem.point_weights, pose[:3], core.rpy_matrix(pose[3:]), half,
            suite.PLANNING_CLEARANCE, problem.weights.collision_stiffness,
        )
        initial_wrenches.append(np.r_[force, torque])

    wall_start, cpu_start = time.perf_counter(), time.process_time()
    record(x0)
    result = minimize(
        evaluate, x0, method="L-BFGS-B", jac=True, bounds=problem.bounds(), callback=record,
        options={"maxiter": maxiter, "ftol": 2.0e-9, "gtol": 1.0e-4, "maxls": 60},
    )
    cpu_seconds = time.process_time() - cpu_start
    wall_seconds = time.perf_counter() - wall_start
    if history[-1]["cost"] != float(result.fun):
        record(result.x)
    tail_start = max(0, len(history) - 51)
    tail = history[tail_start:]
    tail_drop = tail[0]["cost"] - tail[-1]["cost"]
    optimizer = {
        "formal_success": bool(result.success), "message": str(result.message),
        "iterations": int(result.nit), "evaluations": int(result.nfev),
        "initial_cost": history[0]["cost"], "final_cost": float(result.fun),
        "gradient_inf_norm": float(np.linalg.norm(result.jac, ord=np.inf)),
        "projected_gradient_inf_norm": float(np.linalg.norm(projected_gradient(result.x, result.jac, bounds), ord=np.inf)),
        "tail_iteration_count": len(tail) - 1,
        "tail_cost_drop": float(tail_drop),
        "tail_relative_cost_drop": float(tail_drop / max(1.0, abs(tail[0]["cost"]))),
        "wall_seconds": wall_seconds, "cpu_seconds": cpu_seconds,
        "mode": mode, "free_dimensions": problem.free_dims.tolist(),
    }
    return problem.unpack(result.x), optimizer, history, np.asarray(initial_wrenches)


def plan_cloud(task: tuple) -> dict:
    name, cloud, initial, half, height, maxiter, output = task
    trial_dir = Path(output) / "trials"
    summaries = []
    for mode in MODES:
        trajectory, optimizer, history, initial_wrench = optimize_from_cloud(
            cloud, initial, half, height, mode, maxiter,
        )
        prefix = trial_dir / f"{name}__{mode}"
        np.savez_compressed(
            prefix.with_suffix(".npz"), optimized_trajectory=trajectory,
            initial_trajectory=initial, initial_collision_wrench=initial_wrench,
        )
        with prefix.with_suffix(".history.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(history[0]))
            writer.writeheader()
            writer.writerows(history)
        summary = {"scene": name, "mode": mode, "optimizer": optimizer,
                   "initial_sha256": array_digest(initial), "cloud_sha256": array_digest(cloud)}
        write_json(prefix.with_suffix(".json"), summary)
        summaries.append(summary)
        print(f"  planned {name} / {mode}: {optimizer['iterations']} iterations, "
              f"{optimizer['wall_seconds']:.1f}s, pg={optimizer['projected_gradient_inf_norm']:.3g}", flush=True)
    return {"scene": name, "trials": summaries}


def dense_validation(poses: np.ndarray, truth: np.ndarray, half: np.ndarray, subdivisions: int) -> dict:
    dense = core.densify_trajectory(poses, subdivisions)
    distances = np.array([
        core.obb_signed_distance(truth, pose[:3], core.rpy_matrix(pose[3:]), half)[0].min()
        for pose in dense
    ])
    # Bound motion of any body point within each interval. Euler linear
    # interpolation rotates by at most sum(|delta_rpy|), independently of axis.
    motion_bound = (
        np.linalg.norm(np.diff(dense[:, :3], axis=0), axis=1)
        + np.linalg.norm(half) * np.abs(np.diff(dense[:, 3:], axis=0)).sum(axis=1)
    )
    time_lower = float((np.minimum(distances[:-1], distances[1:]) - motion_bound / 2).min())
    # Every synthetic face is a rectangular grid with spacing <= 22 mm;
    # sqrt(2)/2 * spacing bounds the nearest-sample covering radius. This is
    # deliberately conservative (the obstacle grids themselves are <= 7.5 mm).
    cover_radius = math.sqrt(2) * 0.022 / 2
    surface_lower = time_lower - cover_radius
    return {
        "minimum_signed_distance_m": float(distances.min()),
        "collision_free_strict": bool(distances.min() >= 0.0),
        "clearance_20mm_strict": bool(distances.min() >= suite.TARGET_CLEARANCE),
        "legacy_collision_free_with_0p5mm_tolerance": bool(distances.min() >= -0.0005),
        "legacy_clearance_with_1p5mm_tolerance": bool(distances.min() >= suite.TARGET_CLEARANCE - 0.0015),
        "interpolation_subdivisions": subdivisions,
        "checked_pose_count": len(dense),
        "continuous_lower_bound_against_truth_points_m": time_lower,
        "synthetic_surface_cover_radius_m": cover_radius,
        "continuous_lower_bound_against_synthetic_surfaces_m": surface_lower,
        "conservative_continuous_20mm_certificate": bool(surface_lower >= suite.TARGET_CLEARANCE),
        "dense_poses": dense, "dense_clearance": distances,
    }


def plot_results(output: Path, rows: list[dict], scenes: list, half: np.ndarray, height: float) -> None:
    names = [scene.name for scene in scenes]
    indexed = {(row["scene"], row["mode"]): row for row in rows}
    fig, axes = plt.subplots(1, 2, figsize=(16, 9), gridspec_kw={"width_ratios": [1.8, 1]})
    y = np.arange(len(names))
    for offset, mode in zip((-0.24, 0, 0.24), MODES):
        selected = [indexed[name, mode] for name in names]
        axes[0].barh(y + offset, [1000 * r["minimum_signed_distance_m"] for r in selected],
                     height=0.23, label=LABELS[mode], color=COLORS[mode])
        axes[1].scatter([r["cpu_seconds"] for r in selected],
                        [r["projected_gradient_inf_norm"] for r in selected],
                        label=LABELS[mode], color=COLORS[mode], alpha=0.75)
    axes[0].set_yticks(y, names, fontsize=8)
    axes[0].invert_yaxis()
    axes[0].axvline(0, color="tab:red", linewidth=1)
    axes[0].axvline(20, color="k", linestyle="--", label="20 mm target")
    axes[0].set_xlabel("Minimum clearance on held-out dense surfaces [mm]")
    axes[0].legend()
    axes[1].set_yscale("log")
    axes[1].set_xlabel("Optimization process CPU time [s]")
    axes[1].set_ylabel("Final projected gradient infinity norm")
    axes[1].grid(alpha=0.25)
    axes[1].legend()
    fig.suptitle("Uniform straight initialization | identical clouds, objective and weights")
    fig.tight_layout()
    fig.savefig(output / "ablation_summary.png", dpi=160)
    plt.close(fig)

    for name in KEY_SCENES:
        if name not in names:
            continue
        scene = next(s for s in scenes if s.name == name)
        fig, axes = plt.subplots(2, 2, figsize=(13, 8))
        for mode in MODES:
            prefix = output / "trials" / f"{name}__{mode}"
            with np.load(prefix.with_suffix(".npz")) as data:
                trajectory = data["optimized_trajectory"]
            with np.load(prefix.with_suffix(".validation.npz")) as data:
                dense, distances = data["dense_poses"], data["dense_clearance"]
            with prefix.with_suffix(".history.csv").open() as f:
                history = list(csv.DictReader(f))
            axes[0, 0].plot(trajectory[:, 0], trajectory[:, 2], "o-", ms=2, color=COLORS[mode], label=LABELS[mode])
            axes[0, 1].plot(trajectory[:, 0], np.degrees(trajectory[:, 3]), color=COLORS[mode], label=LABELS[mode])
            axes[1, 0].plot(dense[:, 0], 1000 * distances, color=COLORS[mode], label=LABELS[mode])
            axes[1, 1].semilogy([int(r["iteration"]) for r in history],
                                [max(float(r["projected_gradient_inf_norm"]), 1e-12) for r in history],
                                color=COLORS[mode], label=LABELS[mode])
        axes[0, 0].axhline(height, color="0.4", linestyle="--", label="initial height")
        axes[1, 0].axhline(20, color="k", linestyle="--", label="20 mm target")
        axes[1, 0].axhline(0, color="tab:red", linewidth=1)
        for ax, title, ylabel in zip(axes.ravel(),
                                   ("Body height", "Roll discovered from zero", "Independent clearance", "Convergence history"),
                                   ("z [m]", "roll [deg]", "clearance [mm]", "projected gradient infinity norm")):
            ax.set_title(title)
            ax.set_ylabel(ylabel)
            ax.set_xlabel("iteration" if ax is axes[1, 1] else "path x [m]")
            ax.grid(alpha=0.25)
            ax.legend(fontsize=8)
        fig.suptitle(name + " | identical zero-angle initialization")
        fig.tight_layout()
        fig.savefig(output / f"{name}.png", dpi=155)
        plt.close(fig)

        fig = plt.figure(figsize=(15, 5))
        with np.load(output / "scenes" / f"{name}.npz") as data:
            cloud = data["planning_point_cloud"]
        show = cloud[::max(1, len(cloud) // 4000)]
        for index, mode in enumerate(MODES, 1):
            ax = fig.add_subplot(1, 3, index, projection="3d")
            ax.scatter(show[:, 0], show[:, 1], show[:, 2], s=1, alpha=0.28)
            with np.load(output / "trials" / f"{name}__{mode}.npz") as data:
                trajectory = data["optimized_trajectory"]
            ax.plot(*trajectory[:, :3].T, color=COLORS[mode])
            for index in np.linspace(0, len(trajectory) - 1, 6, dtype=int):
                suite.draw_obb(ax, trajectory[index], half, COLORS[mode], alpha=0.7)
            suite.configure_3d_axes(ax)
            clearance = indexed[name, mode]["minimum_signed_distance_m"] * 1000
            ax.set_title(f"{LABELS[mode]} | min {clearance:.1f} mm")
        fig.suptitle(name)
        fig.tight_layout()
        fig.savefig(output / f"{name}_3d.png", dpi=150)
        plt.close(fig)


def write_report(output: Path, metadata: dict, rows: list[dict]) -> None:
    lines = [
        "# M20 统一直线初始化与自由度消融", "",
        "本实验保持原 17 场景、随机种子、点云流程、47 mm 激活距离、目标函数、权重、",
        "边界与 L-BFGS-B 停止条件不变。每个场景三种方法接收完全相同的点云和初始轨迹：",
        "`[x_i, 0, 0.4, 0, 0, 0]`。不使用场景倾角、梁高、建议位姿或真值生成初值。",
        "所有优化结束后才对留出的密集表面评分，不按评分调参、重试或筛选轨迹。", "",
        "## 机器人参数来源", "",
        f"- 来源：`{metadata['robot']['kind']}`。",
        f"- 机身尺寸：`{metadata['robot']['body_size_m']}` m；名义高度：{metadata['robot']['nominal_height_m']:.3f} m。",
        "- 本机缺少原始 URDF/config 时，显式复用已提交结果中的机器人常量；不宣称本轮重新核验了原始模型。", "",
        "## 汇总", "",
        "| 方法 | 严格无碰撞 | 严格 ≥20 mm | 保守连续 ≥20 mm 证书 | 正式收敛 | CPU 时间中位数 | 墙钟时间中位数 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for mode in MODES:
        group = [r for r in rows if r["mode"] == mode]
        lines.append(f"| {LABELS[mode]} | {sum(r['collision_free_strict'] for r in group)}/{len(group)} "
                     f"| {sum(r['clearance_20mm_strict'] for r in group)}/{len(group)} "
                     f"| {sum(r['conservative_continuous_20mm_certificate'] for r in group)}/{len(group)} "
                     f"| {sum(r['formal_success'] for r in group)}/{len(group)} "
                     f"| {np.median([r['cpu_seconds'] for r in group]):.2f} s "
                     f"| {np.median([r['wall_seconds'] for r in group]):.2f} s |")
    lines += ["", "## 每场景的最小间隙", "",
              "| 场景 | XYZ | XYZ+yaw | 6D | 6D 最大 roll/pitch/yaw |",
              "|---|---:|---:|---:|---|", ]
    names = list(dict.fromkeys(r["scene"] for r in rows))
    for name in names:
        group = {r["mode"]: r for r in rows if r["scene"] == name}
        full = group["full"]
        clearances = " | ".join(f"{group[m]['minimum_signed_distance_m']*1000:.2f} mm" for m in MODES)
        lines.append(f"| {name} | {clearances} | "
                     f"{full['max_abs_roll_deg']:.1f}/{full['max_abs_pitch_deg']:.1f}/{full['max_abs_yaw_deg']:.1f}° |")
    lines += ["", "## A/B/C 关键实验", "",
              "| 场景（6D） | 初始→最终最小间隙 | 最低高度 | 中心 roll | 出口区高度恢复最大误差 |",
              "|---|---|---:|---:|---:|", ]
    for name in KEY_SCENES:
        selected = [r for r in rows if r["scene"] == name and r["mode"] == "full"]
        if selected:
            row = selected[0]
            lines.append(f"| {name} | {row['baseline_min_distance_m']*1000:.2f} → "
                         f"{row['minimum_signed_distance_m']*1000:.2f} mm | {row['minimum_base_z_m']:.3f} m "
                         f"| {row['roll_at_center_deg']:.2f}° | {row['exit_height_recovery_max_error_m']*1000:.2f} mm |")
    lines += ["", "## 收敛诊断", "",
              "投影梯度采用单位步长映射 `x - clip(x - grad, lower, upper)`。",
              "记录每次接受迭代的目标值、原始梯度、投影梯度、最低高度与最大姿态角。",
              "最后 50 次迭代相对下降量使用 `Δcost / max(1, |cost_at_tail_start|)`；",
              "少于 50 次时取所有可用迭代。正式收敛、梯度小、几何安全分别报告。", "",
              "| 场景 / 方法（未正式收敛） | 迭代 | 投影梯度 ∞ 范数 | 末 50 次相对下降 |",
              "|---|---:|---:|---:|", ]
    for r in rows:
        if not r["formal_success"]:
            lines.append(f"| {r['scene']} / {LABELS[r['mode']]} | {r['iterations']} "
                         f"| {r['projected_gradient_inf_norm']:.3e} | {r['tail_relative_cost_drop']:.3e} |")
    lines += ["", "## 验收与实验边界", "",
              f"- 每个节点区间做 {metadata['validation_subdivisions']} 等分复检，严格按 `d >= 0` / `d >= 0.020` 计数。",
              "- 同时保留原代码的 0.5 mm 碰撞、1.5 mm 安全目标容差字段，主结果不使用这些容差。",
              "- 连续证书先用相邻复检姿态的平移量与 `||half||·Σ|Δrpy|` 给出区间运动上界，",
              "  从端点间隙减去半个运动上界，再减去合成表面的最大网格覆盖半径（15.56 mm）。",
              "  这是对本实验有限合成表面的保守充分条件；无证书不代表必然碰撞。",
              "  它不包含真实感知、定位或跟踪误差，也不认证实机安全。",
              "- 47 mm 是软惩罚激活距离，不是硬安全约束。本轮为隔离初始化/自由度影响，未改为 barrier 或约束优化。",
              f"- 并发场景数：{metadata['workers']}；BLAS 单线程。墙钟时间受并发调度影响，另报每进程 CPU 时间。",
              "- 每场景固定一个噪声种子；未做多种子成功率或统计显著性检验。",
              "- 14 帧点云来自沿全路线的离线采样，含未来视角，不代表在线探索或单帧感知。",
              "- 姿态范围沿用原规划器的盒约束，尚未由腿轮接触、关节可达性或动力学验证。",
              "- 本轮结果只反映此固定初始化、固定求解预算下的表现，不把局部优化失败解释为方法本身无效。", "",
              "## 文件", "",
              "- `results.json`、`results.csv`：全部方法的指标、协议与软件版本。",
              "- `trials/*.history.csv`：完整迭代诊断；`*.npz`：初始/最终轨迹和初始碰撞 wrench。",
              "- `scenes/*.npz`：三方法共享的点云、留出表面和统一初值。",
              "- `ablation_summary.png` 与 A/B/C 场景图：自由度、姿态发现和收敛情况。", ""]
    (output / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def run(args) -> dict:
    output = args.output.resolve()
    if (output / "protocol.json").exists():
        raise FileExistsError(f"Existing experiment at {output}; choose a new --output")
    output.mkdir(parents=True, exist_ok=True)
    for name in ("trials", "scenes"):
        (output / name).mkdir(exist_ok=True)
    half, height, robot = load_robot(args.urdf, args.m20_config, args.reference_results)
    initial = suite.initial_trajectory(height)
    scenes = suite.build_scenes(height, half)
    metadata = {
        "started_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "robot": robot, "initialization": "uniform_straight_zero_angles",
        "initial_sha256": array_digest(initial), "modes": list(MODES),
        "maxiter": args.maxiter, "workers": args.workers,
        "ftol": 2.0e-9, "gtol": 1.0e-4, "maxls": 60,
        "target_clearance_m": suite.TARGET_CLEARANCE,
        "activation_distance_m": suite.PLANNING_CLEARANCE,
        "weights": asdict(suite.planner_weights()),
        "validation_subdivisions": args.validation_subdivisions,
        "python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__, "platform": platform.platform(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "core_sha256": hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest(),
        "suite_sha256": hashlib.sha256(Path(suite.__file__).read_bytes()).hexdigest(),
        "truth_used_for_planning": False, "scene_hints_used_for_initialization": False,
        "scene_seeds": {scene.name: 1000 + i for i, scene in enumerate(scenes)},
    }
    write_json(output / "protocol.json", metadata)
    tasks = []
    for index, scene in enumerate(scenes):
        cloud, stats = suite.simulate_m20_lidar_cloud(scene.sensor_surface, height, 1000 + index)
        np.savez_compressed(output / "scenes" / f"{scene.name}.npz",
                            planning_point_cloud=cloud, dense_truth_surface=scene.truth_surface,
                            initial_trajectory=initial, body_half_extents=half)
        write_json(output / "scenes" / f"{scene.name}.json", {"cloud_stats": stats, "cloud_sha256": array_digest(cloud)})
        # Workers get neither Scene nor truth; no hint generation is called.
        tasks.append((scene.name, cloud, initial, half, height, args.maxiter, str(output)))
    print(f"Planning {len(tasks)} scenes × {len(MODES)} modes; scoring starts after all planning.", flush=True)
    all_plans = []
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=get_context("spawn")) as executor:
        pending = [executor.submit(plan_cloud, task) for task in tasks]
        for future in as_completed(pending):
            planned = future.result()
            all_plans.extend(planned["trials"])
            print(f"Finished planning {planned['scene']}", flush=True)
    write_json(output / "planning_complete.json", all_plans)
    print("All planning finished. Scoring held-out dense surfaces.", flush=True)
    indexed = {(r["scene"], r["mode"]): r for r in all_plans}
    rows = []
    for scene in scenes:
        baseline = dense_validation(initial, scene.truth_surface, half, args.validation_subdivisions)
        for mode in MODES:
            prefix = output / "trials" / f"{scene.name}__{mode}"
            with np.load(prefix.with_suffix(".npz")) as data:
                trajectory = data["optimized_trajectory"]
            valid = dense_validation(trajectory, scene.truth_surface, half, args.validation_subdivisions)
            np.savez_compressed(prefix.with_suffix(".validation.npz"),
                                dense_poses=valid.pop("dense_poses"), dense_clearance=valid.pop("dense_clearance"))
            full = indexed[scene.name, mode]
            center = int(np.argmin(np.abs(trajectory[:, 0])))
            row = {
                "scene": scene.name, "family": scene.family, "mode": mode,
                "baseline_min_distance_m": baseline["minimum_signed_distance_m"],
                **valid, **full["optimizer"],
                "minimum_base_z_m": float(trajectory[:, 2].min()),
                "maximum_abs_y_m": float(np.abs(trajectory[:, 1]).max()),
                "max_abs_roll_deg": float(np.abs(np.degrees(trajectory[:, 3])).max()),
                "max_abs_pitch_deg": float(np.abs(np.degrees(trajectory[:, 4])).max()),
                "max_abs_yaw_deg": float(np.abs(np.degrees(trajectory[:, 5])).max()),
                "roll_at_center_deg": float(np.degrees(trajectory[center, 3])),
                "exit_height_recovery_max_error_m": float(np.abs(trajectory[trajectory[:, 0] > 0.92, 2] - height).max()),
                "cloud_sha256": full["cloud_sha256"], "initial_sha256": full["initial_sha256"],
            }
            rows.append(row)
        print(f"  scored {scene.name}", flush=True)
    metadata["finished_at"] = datetime.now(ZoneInfo("Asia/Shanghai")).isoformat()
    result = {"metadata": metadata, "trials": rows}
    write_json(output / "results.json", result)
    with (output / "results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    plot_results(output, rows, scenes, half, height)
    write_report(output, metadata, rows)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "results" / "unified_init")
    parser.add_argument("--urdf", type=Path)
    parser.add_argument("--m20-config", type=Path)
    parser.add_argument("--reference-results", type=Path, default=HERE / "artifacts" / "suite_results.json")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--maxiter", type=int, default=300)
    parser.add_argument("--validation-subdivisions", type=int, default=50)
    args = parser.parse_args()
    if min(args.workers, args.maxiter, args.validation_subdivisions) < 1:
        parser.error("workers, maxiter and validation-subdivisions must be positive")
    result = run(args)
    for mode in MODES:
        rows = [row for row in result["trials"] if row["mode"] == mode]
        print(f"{LABELS[mode]}: collision-free {sum(r['collision_free_strict'] for r in rows)}/{len(rows)}, "
              f"20mm {sum(r['clearance_20mm_strict'] for r in rows)}/{len(rows)}")


if __name__ == "__main__":
    main()

# M20 3D Point-Cloud Virtual-Wrench Planner

这是一个面向 DeepRobotics M20 的离线几何验证套件：从三维点云直接计算机身虚拟力与
虚拟力矩，并优化连续的 6D `base_link` 参考轨迹。

## 统一初始化与自由度消融

`run_ablation.py` 使用原来的 17 个场景和点云种子，所有方法统一从
`[x_i, 0, 0.4, 0, 0, 0]` 开始。三组变量分别为 XYZ、XYZ+yaw 和完整 6D。
目标函数、权重、47 mm 激活距离、边界与 300 次迭代预算保持原样，优化器不接收
场景参数、建议姿态或验收真值。所有规划完成后再做独立评分。

```bash
conda env create -f m20_3d_planner/environment.yml
conda activate m20-planner

python -m unittest discover -s m20_3d_planner -p test_ablation.py -v
python m20_3d_planner/run_ablation.py --workers 4
```

默认显式复用 `artifacts/suite_results.json` 中记录的**机器人常量**（机身包围盒、
名义高度与质量），便于在缺少外部模型的机器上复现实验。此模式不重新验证 URDF；
也可同时传入 `--urdf` 和 `--m20-config` 从原始模型读取。

原始结果保存于 `results/unified_init/`：51 次优化、完整迭代历史、共享点云、轨迹、
严格 20 mm 评分、投影梯度、末 50 次目标变化和求解时间。每段轨迹 50 等分复检，
并报告相对于合成表面的保守连续间隙下界。重复实验请用 `--output` 指定新目录。
整理后的报告和图表见 [`artifacts/unified_init/`](artifacts/unified_init/)。

本轮 XYZ、XYZ+yaw、6D 的严格 20 mm 通过数分别为 **12/17、13/17、14/17**，
无碰撞数为 13/17、14/17、15/17。6D 能从零姿态主动降高与侧倾，但 30° 通道
仍有 1.27 mm 节点间穿透，35° 通道也失败；安全与稳定收敛问题尚未解决。
6D 正式收敛 5/17，求解 CPU 时间中位数约 6.83 s。

## 点云优化视频

推荐先看[机身姿态特写版](artifacts/unified_init/videos/attitude/pointcloud_attitude_overview.mp4)：
完整 6D 单独放大，金色顶面、红色机头和白色前进箭头区分机身朝向；正视投影、
独立 roll/pitch/yaw 指示器和同步曲线直接显示侧倾、俯仰与转向。
相机跟随机身位置，观察方向固定。每段 26 秒，保留真实优化迭代、关键姿态停留、
最终轨迹慢放与最差间隙检查，尺寸和角度不夸大。中文说明见
[姿态视频目录](artifacts/unified_init/videos/attitude/README.md)。

[三场景汇总视频](artifacts/unified_init/videos/pointcloud_optimization_overview.mp4)
并排展示 XYZ、XYZ+yaw、完整 6D。每个场景先播放真实优化迭代中的轨迹变化，
再沿最终轨迹移动机身包围盒，最后停在各方法的最小间隙处。红色表示碰撞，
橙色表示不足 20 mm；播放速度仅用于展示。

视频中的迭代位姿来自相同点云、相同初始化和相同参数的确定性重放，并核对终点位姿、
每次接受迭代的目标值与原实验一致。本轮通过确定性重放补录中间位姿，视频对真实
迭代快照做抽样；完整快照保存为 `videos/*.iterations.npz`。

```bash
conda activate m20-planner
python m20_3d_planner/make_optimization_videos.py
python m20_3d_planner/make_attitude_videos.py
```

需要系统安装 FFmpeg。分场景视频与重放校验见
[`artifacts/unified_init/videos/`](artifacts/unified_init/videos/)。

## 历史结果：使用场景先验初始化

原始套件固定参数，包含 17 个场景，但初始轨迹使用了场景给出的梁高、通道倾角等先验：

- 11 个不同高度、yaw、横向倾角和纵向坡度的低梁；
- 4 个 10–35° 倾斜通道；
- 2 个斜梁、不同高度悬障与错位立柱组成的非对称三维场景。

独立密集表面复检结果：17/17 无穿透，14/17 达到 20 mm 安全间隙。三个未达到
安全目标的场景是 20°、30°、35° 倾斜通道，最小间隙分别为 12.1、5.6、16.4 mm。
这反映先验初始化后的轨迹优化能力，不能单独证明从水平直线初值自主发现降高或侧倾。
当前非光滑优化器的安全余量也不够稳定。

规划点云使用 M20 MJCF 中的前后雷达位置，并模拟角度栅格遮挡、距离噪声、7.5% 丢点、
离群点、半径滤波、20 mm 体素化以及沿路径 14 帧融合。密集真值表面只在规划完成后
评分，不参与调参、重试或轨迹选择。

历史结果和可视化位于 [`artifacts/`](artifacts/)。

## 运行

```bash
python -m pip install -r m20_3d_planner/requirements.txt

python m20_3d_planner/run_3d_suite.py \
  --urdf /path/to/deep_robotics_model/M20/urdf/M20.urdf \
  --m20-config /path/to/deeprobotics_m20/rough_env_cfg.py \
  --output m20_3d_planner/results
```

也可以设置 `M20_URDF` 和 `M20_CONFIG` 环境变量后省略对应参数。生成结果包括每个场景
的规划点云、独立真值表面、6D 轨迹、三维图、批量 JSON/CSV 和代表性 MP4 动画。

## 文件

- `m20_core.py`：M20 URDF 机身包络、点到 OBB 的带符号距离、virtual wrench、轨迹优化与独立复检。
- `run_3d_suite.py`：场景生成、M20 前后雷达点云模拟、17 场景批量实验及可视化。
- `run_ablation.py`：统一直线初值、XYZ/XYZ+yaw/6D 对照与收敛诊断。
- `make_attitude_videos.py`：姿态特写、正视投影、单轴角度示意及同步轨迹曲线。
- `test_ablation.py`：梯度、冻结自由度、投影梯度和严格验收的数值检查。
- `artifacts/REPORT.md`：历史场景先验初始化报告。
- `artifacts/suite_results.json`：完整机器可读指标。

## 边界

这里的点云是具有传感器误差模型的**仿真点云**，不是 M20 实机 rosbag/PCD。当前仅验证
机身几何参考轨迹，尚未加入四轮接触、腿长与关节限位、动力学和控制跟踪；不得直接将
轨迹下发到实机。

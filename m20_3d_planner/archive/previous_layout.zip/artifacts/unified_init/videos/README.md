# 点云空间中的优化过程

**观察旋转和倾斜，推荐[新版机身姿态特写](attitude/pointcloud_attitude_overview.mp4)。**
新版把完整 6D 单独放大，提供正视投影、顶面/机头标记、单轴角度指示器和同步曲线；
角度与尺寸保持原实验数值。[新版说明与分场景视频](attitude/README.md)。

[播放三个场景的汇总视频](pointcloud_optimization_overview.mp4)

每个分场景视频 18 秒，三栏依次是只平移、平移加 yaw、完整六维位姿优化：

- [低梁：从水平初值主动降高](beam_h430_yaw00_tilt+0_optimization.mp4)
- [30° 通道：主动侧倾与节点间碰撞](tilted_corridor_30deg_optimization.mp4)
- [非对称障碍：平移和转向的组合](asymmetric_overhang_slalom_optimization.mp4)

前 6 秒是实际优化迭代快照，随后短暂停留，再用 9 秒回放最终轨迹。
最后 2 秒停在各方法的最小间隙位姿，三栏在此阶段可以处于不同路径位置。
播放速度不代表求解速度或机器人的执行速度。

灰色虚线为统一初始轨迹；彩色实线和线框为当前轨迹与机身包围盒。
在轨迹回放和最差位置检查阶段，红色机身表示有穿透，橙色表示间隙不足 20 mm，
绿色表示该帧达到 20 mm。局部间隙与整条轨迹的最小间隙分别标注。
30° 场景的失败如实保留。

迭代快照通过重新运行与原实验相同的优化获得，逐次接受迭代的目标值、最终位姿与
原记录核对。`*_replay.json` 保存校验信息，`*.iterations.npz` 保存完整中间轨迹。
每个优化画面对应一次真实接受的迭代，播放时对这些迭代做时间抽样。
轨迹回放沿用实验的 XYZ/RPY 分段线性插值，属于机身几何可视化。

```bash
conda activate m20-planner
python m20_3d_planner/make_optimization_videos.py
```

使用 `--scenes` 可选具体场景，`--fps` 可调整帧率；编码需要系统 FFmpeg。
生成器写出三个分场景 MP4，汇总视频由这三段直接拼接。

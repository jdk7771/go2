#!/usr/bin/env python3
"""Render actual optimizer iterations followed by point-cloud path playback.

Replay uses the original saved clouds, zero-angle initial poses and solver
settings. It verifies the replayed solution against the saved experiment before
rendering. Frame selection skips accepted iterations but never invents poses
between optimization iterations. Playback follows the experiment's piecewise
linear XYZ/RPY interpolation; it is not a dynamics or tracking simulation.
"""

from __future__ import annotations

import run_ablation as ablation  # Set BLAS thread limits before NumPy imports.

import argparse
import csv
import hashlib
import json
import subprocess
from dataclasses import asdict
from pathlib import Path

import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import Normalize
from mpl_toolkits.mplot3d.art3d import Line3DCollection, Poly3DCollection

import m20_core as core
import run_3d_suite as suite


TITLES = {
    "beam_h430_yaw00_tilt+0": "Low beam: discover lowering from a horizontal start",
    "tilted_corridor_30deg": "30-degree corridor: discover roll, then inspect the collision",
    "asymmetric_overhang_slalom": "Asymmetric obstacles: translation and rotation together",
}
FACES = ([0, 1, 3, 2], [4, 5, 7, 6], [0, 1, 5, 4],
         [2, 3, 7, 6], [0, 2, 6, 4], [1, 3, 7, 5])


def replay_scene(experiment: Path, scene: str, output: Path) -> dict:
    protocol = json.loads((experiment / "protocol.json").read_text())
    if protocol["weights"] != asdict(suite.planner_weights()):
        raise ValueError("Planner weights differ from the recorded experiment")
    if protocol["activation_distance_m"] != suite.PLANNING_CLEARANCE:
        raise ValueError("Planning clearance differs from the recorded experiment")
    for module, key in ((core, "core_sha256"), (suite, "suite_sha256")):
        digest = hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
        if digest != protocol[key]:
            raise ValueError(f"Planning code differs from the experiment: {module.__name__}")
    with np.load(experiment / "scenes" / f"{scene}.npz") as data:
        cloud = data["planning_point_cloud"]
        initial = data["initial_trajectory"]
        half = data["body_half_extents"]
    manifest = {"scene": scene, "experiment": str(experiment.resolve()),
                "phases": ["accepted_optimizer_iterations", "final_trajectory_playback", "worst_clearance_inspection"],
                "cloud_sha256": ablation.array_digest(cloud), "trials": {}}
    for mode in ablation.MODES:
        cache = output / f"{scene}__{mode}.iterations.npz"
        if cache.exists():
            with np.load(cache) as data:
                snapshots, replay_costs = data["poses"], data["costs"]
            poses = snapshots[-1]
        else:
            snapshots = []
            poses, _, history, _ = ablation.optimize_from_cloud(
                cloud, initial, half, protocol["robot"]["nominal_height_m"], mode,
                protocol["maxiter"], pose_history=snapshots,
            )
            replay_costs = np.array([h["cost"] for h in history])
        original = experiment / "trials" / f"{scene}__{mode}"
        with np.load(original.with_suffix(".npz")) as data:
            expected = data["optimized_trajectory"]
        with original.with_suffix(".history.csv").open() as f:
            expected_history = list(csv.DictReader(f))
        original_summary = json.loads(original.with_suffix(".json").read_text())
        if manifest["cloud_sha256"] != original_summary["cloud_sha256"]:
            raise ValueError("Cloud does not match the recorded experiment")
        np.testing.assert_allclose(poses, expected, rtol=1e-8, atol=1e-9)
        if len(snapshots) != len(expected_history):
            raise ValueError("Accepted-iteration count changed during replay")
        np.testing.assert_allclose(replay_costs,
                                   [float(h["cost"]) for h in expected_history],
                                   rtol=1e-8, atol=1e-9)
        np.savez_compressed(
            cache, poses=np.asarray(snapshots),
            iterations=np.arange(len(snapshots)), costs=replay_costs,
        )
        manifest["trials"][mode] = {
            "accepted_iterations": len(snapshots) - 1,
            "maximum_final_pose_difference": float(np.abs(poses - expected).max()),
            "final_cost": float(replay_costs[-1]), "verified_against_original": True,
        }
        print(f"Replayed {scene} / {mode}: {len(snapshots)-1} iterations, verified", flush=True)
    return manifest


def segments(poses: np.ndarray, half: np.ndarray) -> list:
    result = []
    for pose in poses:
        corners = suite.obb_corners(pose, half)
        result.extend(corners[[i, j]] for i, j in suite.BOX_EDGES)
    return result


def clearance_color(distance: float) -> str:
    if distance < 0:
        return "#dc2626"
    return "#d97706" if distance < suite.TARGET_CLEARANCE else "#15803d"


def render_scene(experiment: Path, scene: str, output: Path, fps: int) -> dict:
    with np.load(experiment / "scenes" / f"{scene}.npz") as data:
        cloud, initial, half = data["planning_point_cloud"], data["initial_trajectory"], data["body_half_extents"]
    results = json.loads((experiment / "results.json").read_text())
    rows = {r["mode"]: r for r in results["trials"] if r["scene"] == scene}
    histories, costs, playback, playback_clearance = {}, {}, {}, {}
    for mode in ablation.MODES:
        with np.load(output / f"{scene}__{mode}.iterations.npz") as data:
            histories[mode], costs[mode] = data["poses"], data["costs"]
        with np.load(experiment / "trials" / f"{scene}__{mode}.validation.npz") as data:
            playback[mode], playback_clearance[mode] = data["dense_poses"], data["dense_clearance"]

    # Show more early iterations, where the initially flat path changes fastest.
    optimization_frames, hold_frames, playback_frames, end_frames = 6*fps, fps, 9*fps, 2*fps
    max_iterations = max(len(h) - 1 for h in histories.values())
    shown_iterations = np.rint(np.expm1(np.linspace(0, np.log1p(max_iterations), optimization_frames))).astype(int)
    total_frames = optimization_frames + hold_frames + playback_frames + end_frames
    fig = plt.figure(figsize=(16, 8), facecolor="#f7f9fc")
    axes, paths, envelopes, ghost_boxes, pose_labels, status_labels, head_markers = [], [], [], [], [], [], []
    fig.suptitle(TITLES.get(scene, scene), fontsize=17, y=0.98, fontweight="bold")
    phase_text = fig.text(0.5, 0.925, "", ha="center", fontsize=12)
    fig.text(0.5, 0.025,
             "Point-cloud geometry replay | Gray dashed: initial path | Red: collision, amber: clearance <20 mm | Playback speed is illustrative",
             ha="center", fontsize=9, color="#475569")
    show = cloud[::max(1, len(cloud)//5500)]
    cmap, norm = plt.get_cmap("viridis"), Normalize(0, 0.65)
    point_colors = cmap(norm(show[:, 2]))
    point_colors[:, 3] = np.where(show[:, 2] < 0.025, 0.12, 0.5)

    for index, mode in enumerate(ablation.MODES, 1):
        ax = fig.add_subplot(1, 3, index, projection="3d", facecolor="#f7f9fc")
        ax.scatter(*show.T, c=point_colors, s=1.9, depthshade=False, rasterized=True)
        ax.plot(*initial[:, :3].T, "--", color="#64748b", linewidth=1.2, alpha=0.8)
        path, = ax.plot(*initial[:, :3].T, color=ablation.COLORS[mode], linewidth=2.6)
        marker, = ax.plot([], [], [], "o", color=ablation.COLORS[mode], markersize=4)
        ghosts = Line3DCollection(segments(initial[[4, 7, 11, 15, 18]], half),
                                 colors=ablation.COLORS[mode], linewidths=0.9, alpha=0.35)
        ax.add_collection3d(ghosts)
        initial_corners = suite.obb_corners(initial[len(initial)//2], half)
        body = Poly3DCollection([initial_corners[list(face)] for face in FACES], facecolors=ablation.COLORS[mode],
                                edgecolors=ablation.COLORS[mode], linewidths=1.8, alpha=0.26)
        ax.add_collection3d(body)
        suite.configure_3d_axes(ax)
        ax.view_init(elev=24, azim=-62)
        ax.set_title(ablation.LABELS[mode], fontsize=14, pad=18, fontweight="bold", color=ablation.COLORS[mode])
        ax.tick_params(labelsize=8, pad=0)
        for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
            pane.set_alpha(0.05)
        label = ax.text2D(0.03, -0.03, "", transform=ax.transAxes, fontsize=10, linespacing=1.7)
        status = ax.text2D(0.03, 0.98, "", transform=ax.transAxes, fontsize=11, fontweight="bold")
        axes.append(ax); paths.append(path); ghost_boxes.append(ghosts); envelopes.append(body)
        head_markers.append(marker); pose_labels.append(label); status_labels.append(status)
    fig.subplots_adjust(left=0.015, right=0.985, top=0.85, bottom=0.17, wspace=0.015)

    def update(frame):
        optimizing = frame < optimization_frames
        holding = optimization_frames <= frame < optimization_frames + hold_frames
        if optimizing:
            shared_iteration = int(shown_iterations[frame])
            phase_text.set_text(f"1 / 2   Actual optimization iterations: 0 → {shared_iteration}   (selected accepted iterations)")
        elif holding:
            phase_text.set_text("Optimization complete — inspect the three resulting trajectories")
        elif frame < optimization_frames + hold_frames + playback_frames:
            fraction = np.clip((frame - optimization_frames - hold_frames) / max(1, playback_frames - 1), 0, 1)
            phase_text.set_text("2 / 2   Final trajectory playback through the point cloud")
        else:
            phase_text.set_text("Final inspection: each method's worst-clearance pose on the full path")
        for index, mode in enumerate(ablation.MODES):
            history = histories[mode]
            iteration = min(shared_iteration, len(history)-1) if optimizing else len(history)-1
            poses = history[iteration]
            paths[index].set_data_3d(*poses[:, :3].T)
            ghost_indices = np.linspace(3, len(poses)-4, 5, dtype=int)
            ghost_boxes[index].set_segments(segments(poses[ghost_indices], half))
            if optimizing or holding:
                body_pose = poses[len(poses)//2]
                color = ablation.COLORS[mode]
                status_labels[index].set_text(f"Iteration {iteration} / {len(history)-1}")
                status_labels[index].set_color(color)
                extra = f"cost: {costs[mode][iteration]:.3g}  |  max |roll|: {np.abs(np.degrees(poses[:,3])).max():.1f}°"
            else:
                location = (int(round(fraction * (len(playback[mode])-1)))
                            if frame < optimization_frames + hold_frames + playback_frames
                            else int(np.argmin(playback_clearance[mode])))
                body_pose = playback[mode][location]
                distance = float(playback_clearance[mode][location])
                color = clearance_color(distance)
                status = "COLLISION" if distance < 0 else ("Below 20 mm" if distance < 0.020 else "Clearance ≥20 mm")
                status_labels[index].set_text(f"{status}  |  local {distance*1000:+.1f} mm")
                status_labels[index].set_color(color)
                extra = f"whole-path minimum: {rows[mode]['minimum_signed_distance_m']*1000:+.2f} mm"
            corners = suite.obb_corners(body_pose, half)
            envelopes[index].set_verts([corners[list(face)] for face in FACES])
            envelopes[index].set_edgecolor(color)
            envelopes[index].set_facecolor(color)
            head_markers[index].set_data_3d(*body_pose[:3, None])
            pose_labels[index].set_text(
                f"z: {body_pose[2]:.3f} m    r/p/y: {np.degrees(body_pose[3]):+.1f} / "
                f"{np.degrees(body_pose[4]):+.1f} / {np.degrees(body_pose[5]):+.1f}°\n{extra}"
            )
        return []

    writer = animation.FFMpegWriter(
        fps=fps, codec="libx264", bitrate=-1,
        extra_args=["-crf", "20", "-preset", "fast", "-pix_fmt", "yuv420p", "-movflags", "+faststart"],
        metadata={"title": TITLES.get(scene, scene), "comment": "Verified optimizer replay followed by geometric trajectory playback"},
    )
    path = output / f"{scene}_optimization.mp4"
    with writer.saving(fig, str(path), dpi=110):
        for frame in range(total_frames):
            update(frame)
            writer.grab_frame(facecolor=fig.get_facecolor())
            if frame == optimization_frames - 1:
                fig.savefig(output / f"{scene}_optimization_poster.png", dpi=110, facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"Rendered {path.name}: {total_frames} frames at {fps} fps", flush=True)
    return {"video": path.name, "frames": total_frames, "fps": fps, "duration_seconds": total_frames/fps}


def concatenate_videos(output: Path, scenes: list[str]) -> Path:
    listing = output / "overview.ffconcat"
    filenames = [f"{scene}_optimization.mp4" for scene in scenes]
    for name in filenames:
        if not (output / name).exists():
            raise FileNotFoundError(output / name)
    listing.write_text("ffconcat version 1.0\n" + "".join(
        "file '" + name.replace("'", "'\\''") + "'\n" for name in filenames
    ), encoding="utf-8")
    overview = output / "pointcloud_optimization_overview.mp4"
    subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
        "-i", str(listing), "-c", "copy", "-movflags", "+faststart", str(overview),
    ], check=True)
    print(f"Combined {len(scenes)} scenes: {overview}", flush=True)
    return overview


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", type=Path, default=ablation.HERE / "results" / "unified_init")
    parser.add_argument("--output", type=Path, default=ablation.HERE / "artifacts" / "unified_init" / "videos")
    parser.add_argument("--scenes", nargs="+", default=list(ablation.KEY_SCENES))
    parser.add_argument("--fps", type=int, default=18)
    args = parser.parse_args()
    if args.fps < 1:
        parser.error("--fps must be positive")
    if not animation.writers.is_available("ffmpeg"):
        parser.error("ffmpeg is required to write H.264 MP4 files")
    args.output.mkdir(parents=True, exist_ok=True)
    for scene in args.scenes:
        manifest = replay_scene(args.experiment, scene, args.output)
        manifest.update(render_scene(args.experiment, scene, args.output, args.fps))
        ablation.write_json(args.output / f"{scene}_replay.json", manifest)
    if len(args.scenes) > 1:
        concatenate_videos(args.output, args.scenes)


if __name__ == "__main__":
    main()

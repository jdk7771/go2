#!/usr/bin/env python3
"""Build a GE6001 revision from the supplied DOCX, using only Python's stdlib.

The tracked Word document contains native w:ins/w:del revisions. A separate
static markup document is used for PDF export so the PDF always shows changes.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
from difflib import SequenceMatcher
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent.parent
SOURCE_DEFAULT = Path('/home/jiang/Downloads/Homework-final.docx')
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
XML_SPACE = '{http://www.w3.org/XML/1998/namespace}space'
DATE = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
ET.register_namespace('w', W)

REVISED = [
    '''Cloud computing is a rapidly growing industry that provides IT resources, including applications, computing power, and data storage, over the Internet. Enterprises use platforms such as Amazon Web Services (AWS), Microsoft Azure, Google Cloud, and Alibaba Cloud to host software and data, reduce IT costs, scale resources, and support collaboration. Virtualization is a key enabling technology that abstracts physical server resources and supports multiple virtual environments. Cloud networking connects these environments, making reliable connectivity essential to service availability. In large cloud deployments, complex communication relationships among virtual nodes make connectivity difficult to diagnose. Visibility into packet transmission paths and connection status can help network administrators locate faults and reduce troubleshooting effort. Tenants can also use connectivity information to inform load balancing and fault tolerance strategies.''',
    '''Diagnosing network connectivity remains challenging. In traditional networks, administrators often inspect router configurations and use tools such as ping and traceroute to identify faulty devices or links. Applying these procedures manually to networks with millions of nodes is impractical. With the adoption of software-defined networking (SDN) and Virtual Extensible LAN (VXLAN) [4], connectivity analysis also needs to account for communication between virtual nodes in overlay networks. SDN offers centralized control, programmable forwarding behavior, and network-wide visibility, enabling administrators to configure virtual forwarding devices, such as virtual switches and routers. These capabilities create opportunities for automated, network-wide connectivity diagnosis.''',
    '''Existing SDN research has sought to improve network operation [6, 7, 9, 35], while other work has developed techniques for monitoring and debugging. Some systems require extensive network instrumentation [3, 11, 12, 37], which may complicate deployment in large cloud environments. Other approaches exploit SDN programmability to trace packets by modifying virtual forwarding devices [13, 33], deploying decision engines on end hosts [8, 27], or mirroring packets [1, 15]. These approaches illustrate the capabilities of SDN-based tracing, but deployment complexity and tracing overhead remain important considerations for cloud-scale networks.

To address these considerations, we present VTrace, a network debugging tool that traces virtual flows, reconstructs their forwarding paths, and helps identify the causes of connectivity failures. VTrace uses the SDN controller's network-wide visibility to configure tracing on virtual forwarding devices and employs distributed stream processing to reconstruct and analyze flows.''',
    '''This paper makes three contributions:

(1) We present VTrace, a traceback analysis system designed for large-scale cloud overlay networks. The system traces virtual flows to expose forwarding paths and help locate connectivity failures.

(2) We develop an SDN-based tracing mechanism that uses the controller's network-wide visibility to configure virtual forwarding devices for tracing arbitrary virtual flows. The mechanism is designed to limit tracing overhead and disruption to production traffic.

(3) We develop a distributed stream-processing system for reconstructing and analyzing virtual flows. The system is designed to support concurrent tracing tasks and timely analysis.''',
]


def node(tag, parent=None, **attrs):
    out = ET.Element(f'{{{W}}}{tag}', {f'{{{W}}}{k}': str(v) for k, v in attrs.items()})
    if parent is not None:
        parent.append(out)
    return out


def run(parent, text, kind='equal', native=False, bold=False, size=None):
    r = node('r', parent)
    props = node('rPr', r)
    node('rFonts', props, ascii='Liberation Serif', hAnsi='Liberation Serif')
    if bold:
        node('b', props)
    if size:
        node('sz', props, val=size)
    if not native and kind != 'equal':
        node('color', props, val='B00020' if kind == 'delete' else '1453A0')
        node('strike' if kind == 'delete' else 'u', props, **({} if kind == 'delete' else {'val': 'single'}))
    t = node('delText' if native and kind == 'delete' else 't', r)
    t.set(XML_SPACE, 'preserve')
    t.text = text
    return r


def paragraph(parent, text=None, style='Normal', size=None, bold=False):
    p = node('p', parent)
    pp = node('pPr', p)
    node('pStyle', pp, val=style)
    if style == 'Normal':
        node('jc', pp, val='both')
    if text is not None:
        run(p, text, size=size, bold=bold)
    return p


def tokenise(text):
    # Keep citation groups intact so the redline cannot split a reference number.
    # Paragraph boundaries are tokens; other whitespace belongs to its word.
    return re.findall(r'\[[\d, ]+\][^\S\n]*|\n\n|[^\s]+[^\S\n]*', text)


def changes(old, new):
    a, b = tokenise(old), tokenise(new)
    out = []
    for tag, i, j, k, l in SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == 'equal':
            out.append(('equal', ''.join(a[i:j])))
        else:
            if tag in ('delete', 'replace'):
                out.append(('delete', ''.join(a[i:j])))
            if tag in ('insert', 'replace'):
                out.append(('insert', ''.join(b[k:l])))
    return out


def normalise(s):
    return ' '.join(s.split())


def get_original(path):
    with ZipFile(path) as z:
        root = ET.fromstring(z.read('word/document.xml'))
    pars = [''.join(p.itertext()) for p in root.findall('./w:body/w:p', NS)]
    original = [p for p in pars if p.startswith(('Cloud computing ', 'Unfortunately, ', 'And we ', 'The contributions '))]
    if len(original) != 4:
        raise ValueError(f'Expected four introduction paragraphs, found {len(original)}')
    return original


def create_docx(path, original, mode):
    doc = node('document')
    body = node('body', doc)
    paragraph(body, 'GE6001 | Academic Writing, Norms and Ethics', 'Title', size=30, bold=True)
    subtitle = 'Introduction — Clean Revision' if mode == 'clean' else 'Introduction — Tracked Revision'
    paragraph(body, subtitle, 'Subtitle', size=25, bold=True)
    if mode != 'clean':
        p = paragraph(body, style='Legend')
        run(p, 'Deleted text', kind='delete', size=20)
        run(p, '   |   ', size=20)
        run(p, 'Inserted text', kind='insert', size=20)
        paragraph(body, 'All reference numbers are retained from the supplied text.', 'Legend', size=19)
    else:
        paragraph(body, 'All reference numbers are retained from the supplied text.', 'Legend', size=19)
    revision_id = 1
    for old, new in zip(original, REVISED):
        if mode == 'clean':
            for part in new.split('\n\n'):
                paragraph(body, part)
            continue
        p = paragraph(body)
        for kind, value in changes(old, new):
            pieces = value.split('\n\n')
            for i, piece in enumerate(pieces):
                if i:
                    p = paragraph(body)
                    # Mark inserted paragraph breaks as revisions as well.
                    if mode == 'tracked' and kind == 'insert':
                        pp = p.find(f'{{{W}}}pPr')
                        rp = node('rPr', pp)
                        node('ins', rp, id=revision_id, author='Editor', date=DATE)
                        revision_id += 1
                if not piece:
                    continue
                target = p
                if mode == 'tracked' and kind != 'equal':
                    target = node('del' if kind == 'delete' else 'ins', p,
                                  id=revision_id, author='Editor', date=DATE)
                    revision_id += 1
                run(target, piece, kind, native=(mode == 'tracked'))
    sect = node('sectPr', body)
    node('pgSz', sect, w=11906, h=16838)
    node('pgMar', sect, top=1134, right=1190, bottom=1134, left=1190, header=567, footer=567, gutter=0)
    footerref = node('footerReference', sect, type='default')
    footerref.set('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id', 'rIdFooter')

    footer = node('ftr')
    p = paragraph(footer, style='Footer')
    pp = p.find(f'{{{W}}}pPr')
    node('jc', pp, val='center')
    run(p, 'GE6001  |  ')
    field = node('fldSimple', p, instr='PAGE')
    run(field, '1')

    styles = node('styles')
    defaults = node('docDefaults', styles)
    rp = node('rPr', node('rPrDefault', defaults))
    node('rFonts', rp, ascii='Liberation Serif', hAnsi='Liberation Serif')
    node('sz', rp, val=23)
    node('lang', rp, val='en-US')
    pp = node('pPr', node('pPrDefault', defaults))
    node('spacing', pp, after=150, line=290, lineRule='auto')
    node('widowControl', pp)
    for name in ('Normal', 'Title', 'Subtitle', 'Legend', 'Footer'):
        st = node('style', styles, type='paragraph', styleId=name)
        node('name', st, val=name)
        if name == 'Normal':
            st.set(f'{{{W}}}default', '1')
        else:
            node('basedOn', st, val='Normal')
        if name != 'Normal':
            pp = node('pPr', st)
            node('spacing', pp, after=110 if name in ('Title', 'Subtitle') else 130)
            if name in ('Title', 'Subtitle', 'Legend'):
                node('keepNext', pp)

    settings = node('settings')
    if mode == 'tracked':
        node('revisionView', settings, markup='true', insDel='true', formatting='true')
        node('trackRevisions', settings)
        node('doNotTrackFormatting', settings)
    node('defaultTabStop', settings, val=720)

    def serial(e):
        return ET.tostring(e, encoding='UTF-8', xml_declaration=True)

    package = {
        '[Content_Types].xml': b'''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>''',
        '_rels/.rels': b'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>''',
        'word/_rels/document.xml.rels': b'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rIdSettings" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/><Relationship Id="rIdFooter" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>''',
        'word/document.xml': serial(doc),
        'word/styles.xml': serial(styles),
        'word/settings.xml': serial(settings),
        'word/footer1.xml': serial(footer),
    }
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        for name, value in package.items():
            z.writestr(name, value)


def tex_escape(s):
    replacements = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$',
                    '#': r'\#', '_': r'\_', '{': r'\{', '}': r'\}', '~': r'\textasciitilde{}',
                    '^': r'\textasciicircum{}', '—': '---', '–': '--', '’': "'"}
    return ''.join(replacements.get(c, c) for c in s)


def create_tex(original):
    marked = []
    for old, new in zip(original, REVISED):
        parts = []
        for kind, value in changes(old, new):
            chunks = value.split('\n\n')
            for i, chunk in enumerate(chunks):
                if i:
                    parts.append('\n\n')
                if chunk:
                    escaped = tex_escape(chunk)
                    parts.append(escaped if kind == 'equal' else '\\' + ('deleted' if kind == 'delete' else 'added') + '{' + escaped + '}')
        marked.append(''.join(parts))
    preamble = r'''% Compile twice with pdfLaTeX, XeLaTeX, or LuaLaTeX.
% Default: a marked revision followed by a clean reading copy.
% For only the marked revision: change \cleansectiontrue to \cleansectionfalse.
% For only the clean revision: change \markedsectiontrue to \markedsectionfalse.
% Citation numbers are copied verbatim; the source did not include a bibliography.
\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{lmodern}
\usepackage[margin=23mm]{geometry}
\usepackage{xcolor}
\usepackage[normalem]{ulem}
\usepackage{microtype}
\usepackage{fancyhdr}
\definecolor{deletion}{HTML}{B00020}
\definecolor{insertion}{HTML}{1453A0}
\newcommand{\deleted}[1]{{\color{deletion}\sout{#1}}}
\newcommand{\added}[1]{{\color{insertion}\uline{#1}}}
\newif\ifmarkedsection
\newif\ifcleansection
\markedsectiontrue
\cleansectiontrue
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.65\baselineskip}
\linespread{1.08}
\setlength{\emergencystretch}{3em}
\pagestyle{fancy}
\fancyhf{}
\fancyfoot[C]{\small GE6001\quad |\quad \thepage}
\renewcommand{\headrulewidth}{0pt}
\begin{document}
\ifmarkedsection
{\Large\bfseries GE6001 | Academic Writing, Norms and Ethics\par}
{\large\bfseries Introduction --- Tracked Revision\par}
{\small \deleted{Deleted text}\quad |\quad \added{Inserted text}\par}
{\small All reference numbers are retained from the supplied text.\par}

'''
    middle = r'''
\fi
\ifcleansection
\ifmarkedsection\clearpage\fi
{\Large\bfseries GE6001 | Academic Writing, Norms and Ethics\par}
{\large\bfseries Introduction --- Clean Revision\par}
{\small All reference numbers are retained from the supplied text.\par}

'''
    content = preamble + '\n\n'.join(marked) + '\n' + middle + '\n\n'.join(tex_escape(x) for x in REVISED) + '\n\\fi\n\\end{document}\n'
    (ROOT / 'Homework-final.tex').write_text(content)


def validate(original):
    reports = []
    for i, (old, new) in enumerate(zip(original, REVISED), 1):
        diff = changes(old, new)
        rejected = ''.join(v for k, v in diff if k != 'insert')
        accepted = ''.join(v for k, v in diff if k != 'delete')
        assert normalise(rejected) == normalise(old), f'Original reconstruction failed: {i}'
        assert normalise(accepted) == normalise(new), f'Revision reconstruction failed: {i}'
        old_cites, new_cites = re.findall(r'\[[\d, ]+\]', old), re.findall(r'\[[\d, ]+\]', new)
        assert Counter(old_cites) == Counter(new_cites), f'Citations changed: {i}'
        reports.append({'paragraph': i, 'original_words': len(old.split()), 'revised_words': len(new.split()),
                        'reconstruct_original': True, 'reconstruct_revision': True, 'citations_preserved': True})
    with ZipFile(ROOT / 'Homework-final-tracked.docx') as z:
        doc = ET.fromstring(z.read('word/document.xml'))
        counts = {kind: len(doc.findall(f'.//w:{kind}', NS)) for kind in ('ins', 'del')}
        assert counts['ins'] and counts['del']
        def extract(accept):
            pieces = []
            for p in doc.findall('./w:body/w:p', NS)[4:]:
                def walk(e):
                    if e.tag == f'{{{W}}}' + ('del' if accept else 'ins'):
                        return ''
                    if e.tag in (f'{{{W}}}t', f'{{{W}}}delText'):
                        return e.text or ''
                    return ''.join(walk(c) for c in e)
                pieces.append(walk(p))
            return normalise(' '.join(pieces))
        assert extract(True) == normalise(' '.join(REVISED)), 'DOCX accept all did not reproduce revision'
        assert extract(False) == normalise(' '.join(original)), 'DOCX reject all did not reproduce original'
    summary = {'checks': reports, 'native_word_revisions': counts, 'docx_accept_all_correct': True,
               'docx_reject_all_correct': True}
    (ROOT / 'build/validation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('original_docx', type=Path, nargs='?', default=SOURCE_DEFAULT)
    args = parser.parse_args()
    ROOT.mkdir(exist_ok=True)
    (ROOT / 'build').mkdir(exist_ok=True)
    original = get_original(args.original_docx)
    create_docx(ROOT / 'Homework-final-tracked.docx', original, 'tracked')
    create_docx(ROOT / 'build/Homework-final-marked.docx', original, 'marked')
    create_docx(ROOT / 'Homework-final-clean.docx', original, 'clean')
    create_tex(original)
    (ROOT / 'source/revised_introduction.txt').write_text('\n\n'.join(REVISED) + '\n')
    (ROOT / 'build/revisions.json').write_text(json.dumps({'original': original, 'revised': REVISED}, ensure_ascii=False, indent=2))
    validate(original)


if __name__ == '__main__':
    main()
